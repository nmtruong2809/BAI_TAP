--Câu 1.1: Tạo view
CREATE OR REPLACE VIEW vw_course_summary AS
SELECT co.courseno, 
       co.description, 
       co.cost, 
       COUNT(DISTINCT cl.classid) AS so_lop, 
       COUNT(e.studentid) AS tong_sv
FROM course co
LEFT JOIN class cl ON co.courseno = cl.courseno
LEFT JOIN enrollment e ON cl.classid = e.classid
GROUP BY co.courseno, co.description, co.cost
ORDER BY tong_sv DESC;
--Câu 1.2:
CREATE OR REPLACE VIEW vw_student_status AS
SELECT s.studentid, 
       s.firstname || ' ' || s.lastname AS ho_ten, 
       COUNT(e.classid) AS so_lop_hoc, 
       NVL(SUM(co.cost), 0) AS tong_hoc_phi, 
       ROUND(AVG(e.finalgrade), 2) AS diem_tb
FROM student s
JOIN enrollment e ON s.studentid = e.studentid
JOIN class cl ON e.classid = cl.classid
JOIN course co ON cl.courseno = co.courseno
GROUP BY s.studentid, s.firstname, s.lastname
HAVING COUNT(e.classid) >= 1
ORDER BY s.studentid;
--Câu 1.3:
CREATE OR REPLACE VIEW vw_class_availability AS
SELECT cl.classid, 
       cl.courseno, 
       co.description, 
       i.firstname || ' ' || i.lastname AS ten_giao_vien, 
       cl.capacity, 
       COUNT(e.studentid) AS so_da_dk, 
       cl.capacity - COUNT(e.studentid) AS cho_trong,
       CASE 
           WHEN cl.capacity - COUNT(e.studentid) > 0 THEN 'Con cho' 
           ELSE 'Het cho' 
       END AS trang_thai
FROM class cl
JOIN course co ON cl.courseno = co.courseno
JOIN instructor i ON cl.instructorid = i.instructorid
LEFT JOIN enrollment e ON cl.classid = e.classid
GROUP BY cl.classid, cl.courseno, co.description, i.firstname, i.lastname, cl.capacity
HAVING cl.capacity - COUNT(e.studentid) > 0
ORDER BY cl.classid;
--Câu 1.4:
CREATE OR REPLACE VIEW vw_top_courses AS
SELECT courseno, description, cost, tong_dk, hang
FROM (
    SELECT co.courseno, 
           co.description, 
           co.cost, 
           COUNT(e.studentid) AS tong_dk,
           RANK() OVER (ORDER BY COUNT(e.studentid) DESC) AS hang
    FROM course co
    LEFT JOIN class cl ON co.courseno = cl.courseno
    LEFT JOIN enrollment e ON cl.classid = e.classid
    GROUP BY co.courseno, co.description, co.cost
)
WHERE hang <= 5
ORDER BY hang
WITH READ ONLY;
--Câu 1.5:
CREATE OR REPLACE VIEW vw_pending_enrollment AS
SELECT studentid, classid, enrolldate, finalgrade, createdby, createddate, modifiedby, modifieddate
FROM enrollment
WHERE finalgrade IS NULL
WITH CHECK OPTION;
--Câu 2.1:
CREATE OR REPLACE PROCEDURE enroll_student (
    p_studentid IN NUMBER, 
    p_classid IN NUMBER
) IS
    v_check NUMBER;
    v_capacity NUMBER;
    v_enrolled NUMBER;
BEGIN
    -- DK1: Sinh viên tồn tại
    SELECT COUNT(*) INTO v_check FROM student WHERE studentid = p_studentid;
    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien ' || p_studentid || ' khong ton tai!');
        RETURN;
    END IF;

    -- DK2: Lớp học tồn tại
    SELECT COUNT(*) INTO v_check FROM class WHERE classid = p_classid;
    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop hoc ' || p_classid || ' khong ton tai!');
        RETURN;
    END IF;

    -- DK3: Kiểm tra còn chỗ trống
    SELECT capacity INTO v_capacity FROM class WHERE classid = p_classid;
    SELECT COUNT(*) INTO v_enrolled FROM enrollment WHERE classid = p_classid;
    IF v_enrolled >= v_capacity THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop ' || p_classid || ' da day! (' || v_enrolled || '/' || v_capacity || ')');
        RETURN;
    END IF;

    -- DK4: Sinh viên chưa đăng ký lớp này
    SELECT COUNT(*) INTO v_check FROM enrollment WHERE studentid = p_studentid AND classid = p_classid;
    IF v_check > 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky lop nay roi!');
        RETURN;
    END IF;

    -- DK5: Sinh viên chưa đăng ký quá 3 lớp
    SELECT COUNT(*) INTO v_check FROM enrollment WHERE studentid = p_studentid;
    IF v_check >= 3 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky du 3 lop!');
        RETURN;
    END IF;

    -- Vượt qua các kiểm tra -> Đăng ký lớp
    INSERT INTO enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate)
    VALUES (p_studentid, p_classid, SYSDATE, USER, SYSDATE, USER, SYSDATE);
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('[THANH CONG] Da dang ky sinh vien ' || p_studentid || ' vao lop ' || p_classid);
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM);
END;
/
--Câu 2.3:
CREATE OR REPLACE PROCEDURE transfer_student (
    p_studentid IN NUMBER, 
    p_old_classid IN NUMBER, 
    p_new_classid IN NUMBER
) IS
    v_check NUMBER;
    v_capacity NUMBER;
    v_enrolled NUMBER;
BEGIN
    -- DK1: Đang học lớp cũ
    SELECT COUNT(*) INTO v_check FROM enrollment WHERE studentid = p_studentid AND classid = p_old_classid;
    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien khong dang hoc lop ' || p_old_classid);
        RETURN;
    END IF;

    -- DK2: Lớp mới còn chỗ
    SELECT capacity INTO v_capacity FROM class WHERE classid = p_new_classid;
    SELECT COUNT(*) INTO v_enrolled FROM enrollment WHERE classid = p_new_classid;
    IF v_enrolled >= v_capacity THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop moi ' || p_new_classid || ' da day!');
        RETURN;
    END IF;

    -- Thực hiện chuyển đổi
    SAVEPOINT sp_start;
    
    DELETE FROM enrollment WHERE studentid = p_studentid AND classid = p_old_classid;
    
    INSERT INTO enrollment (studentid, classid, enrolldate, createdby, createddate, modifiedby, modifieddate)
    VALUES (p_studentid, p_new_classid, SYSDATE, USER, SYSDATE, USER, SYSDATE);
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('[THANH CONG] Chuyen lop hoan tat!');
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO sp_start;
        DBMS_OUTPUT.PUT_LINE('Loi trong qua trinh chuyen lop: ' || SQLERRM);
END;
/
--Câu 3.1:
CREATE OR REPLACE TRIGGER trg_check_capacity
BEFORE INSERT ON enrollment
FOR EACH ROW
DECLARE
    v_capacity NUMBER;
    v_enrolled NUMBER;
BEGIN
    SELECT capacity INTO v_capacity FROM class WHERE classid = :NEW.classid;
    SELECT COUNT(*) INTO v_enrolled FROM enrollment WHERE classid = :NEW.classid;
    
    IF v_enrolled >= v_capacity THEN
        RAISE_APPLICATION_ERROR(-20010, 'Lop hoc da day!');
    END IF;
END;
/
--Câu 3.2:
-- Tạo bảng Audit
CREATE TABLE grade_audit_log (
    log_id NUMBER GENERATED ALWAYS AS IDENTITY,
    studentid NUMBER(8),
    classid NUMBER(8),
    grade_cu NUMBER(3),
    grade_moi NUMBER(3),
    nguoi_sua VARCHAR2(30),
    thoi_gian DATE
);
/

CREATE OR REPLACE TRIGGER trg_grade_audit_log
AFTER UPDATE OF finalgrade ON enrollment
FOR EACH ROW
BEGIN
    IF (:OLD.finalgrade IS NULL AND :NEW.finalgrade IS NOT NULL) OR 
       (:OLD.finalgrade IS NOT NULL AND :NEW.finalgrade IS NULL) OR 
       (:OLD.finalgrade != :NEW.finalgrade) THEN
        INSERT INTO grade_audit_log (studentid, classid, grade_cu, grade_moi, nguoi_sua, thoi_gian)
        VALUES (:NEW.studentid, :NEW.classid, :OLD.finalgrade, :NEW.finalgrade, USER, SYSDATE);
    END IF;
END;
/
--Câu 3.3:
CREATE OR REPLACE TRIGGER trg_prevent_course_delete
BEFORE DELETE ON course
FOR EACH ROW
DECLARE
    v_so_lop NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_so_lop FROM class WHERE courseno = :OLD.courseno;
    IF v_so_lop > 0 THEN
        RAISE_APPLICATION_ERROR(-20020, 'Khong the xoa mon hoc dang co lop!');
    END IF;
END;
/
--Câu 3.4:
-- Bảng thống kê
CREATE TABLE class_grade_summary (
    classid NUMBER(8) PRIMARY KEY,
    so_sv NUMBER,
    diem_tb NUMBER(5,2),
    diem_cao_nhat NUMBER(3),
    diem_thap_nhat NUMBER(3),
    cap_nhat_luc DATE
);
/

CREATE OR REPLACE TRIGGER trg_update_grade_summary
AFTER INSERT OR UPDATE OR DELETE ON enrollment
FOR EACH ROW
DECLARE
    v_classid NUMBER;
    v_so_sv NUMBER;
    v_diem_tb NUMBER;
    v_max_d NUMBER;
    v_min_d NUMBER;
BEGIN
    IF INSERTING OR UPDATING THEN
        v_classid := :NEW.classid;
    ELSE
        v_classid := :OLD.classid;
    END IF;

    SELECT COUNT(finalgrade), ROUND(AVG(finalgrade), 2), MAX(finalgrade), MIN(finalgrade)
    INTO v_so_sv, v_diem_tb, v_max_d, v_min_d
    FROM enrollment WHERE classid = v_classid;

    MERGE INTO class_grade_summary c
    USING (SELECT v_classid AS cid, v_so_sv AS s, v_diem_tb AS t, v_max_d AS m, v_min_d AS mn FROM dual) n
    ON (c.classid = n.cid)
    WHEN MATCHED THEN
        UPDATE SET so_sv = n.s, diem_tb = n.t, diem_cao_nhat = n.m, diem_thap_nhat = n.mn, cap_nhat_luc = SYSDATE
    WHEN NOT MATCHED THEN
        INSERT (classid, so_sv, diem_tb, diem_cao_nhat, diem_thap_nhat, cap_nhat_luc)
        VALUES (n.cid, n.s, n.t, n.m, n.mn, SYSDATE);
END;
/
--Câu 4.1:
CREATE OR REPLACE VIEW vw_instructor_workload AS
SELECT i.instructorid, 
       i.firstname || ' ' || i.lastname AS ho_ten, 
       COUNT(DISTINCT cl.classid) AS so_lop, 
       COUNT(e.studentid) AS tong_sv, 
       ROUND(AVG(e.finalgrade), 2) AS diem_tb_chung,
       CASE 
           WHEN COUNT(DISTINCT cl.classid) >= 3 THEN 'Ban nhieu'
           WHEN COUNT(DISTINCT cl.classid) = 2 THEN 'Binh thuong'
           ELSE 'Nhe nhang' 
       END AS muc_ban
FROM instructor i
LEFT JOIN class cl ON i.instructorid = cl.instructorid
LEFT JOIN enrollment e ON cl.classid = e.classid
GROUP BY i.instructorid, i.firstname, i.lastname
ORDER BY so_lop DESC;